$( window ).load(function() {
  $('.playbtn-close').click(function () {
    $('.wrapper-play-btn').hide();
  })
});
