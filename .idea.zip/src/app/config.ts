import { Injectable } from '@angular/core';

@Injectable()
export class Config {
  // public static api: String = 'https://influexpapi.herokuapp.com';
  // public static api: String = 'http://ns520442.ip-158-69-23.net:4433';
  // public static api: String = 'http://192.168.29.109:7000';
    public static api: String = 'https://apis.influexpai.com';
    // public static api: String = 'https://devapis.influexpai.com';
}
