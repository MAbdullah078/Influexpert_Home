import {Component, OnInit} from '@angular/core';


@Component({
    selector: 'app-dashboard',
    templateUrl: './manage-review.component.html',
    styleUrls: ['./manage-reviews.component.css'],
})

export class ManageReviewsComponent implements OnInit {

    checkflag: any;

    ngOnInit(){}

}