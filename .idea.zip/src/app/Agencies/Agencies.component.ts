import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-agency',
    templateUrl: './Agencies.component.html',
    styleUrls: ['./Agencies.component.css']
})
export class AgenciesComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
